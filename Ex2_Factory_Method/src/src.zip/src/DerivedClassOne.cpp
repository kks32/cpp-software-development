#include "DerivedClassOne.h"
#include "MyFactory.h"

REGISTER_CLASS("one", DerivedClassOne);