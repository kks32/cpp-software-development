#include "DerivedClassTwo.h"
#include "MyFactory.h"

REGISTER_CLASS("two", DerivedClassTwo);

