#ifndef CPPFACTORY_MYBASECLASS_H
#define CPPFACTORY_MYBASECLASS_H

class MyBaseClass
{
public:
    virtual void doSomething() = 0;
};

#endif // CPPFACTORY_MYBASECLASS_H